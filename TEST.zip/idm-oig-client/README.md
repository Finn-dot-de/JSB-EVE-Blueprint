# idm-oig-client

SCIM-2.0-Hub: nimmt SCIM-Requests eines IdP entgegen (`/scim/v2/Users`,
`/scim/v2/Groups`) und reicht sie an die Oracle-Identity-Governance-SCIM-API
weiter. Keine eigene Datenhaltung.

```
IdP (z.B. Entra ID) ──SCIM──▶ idm-oig-client ──SCIM──▶ OIG
                              /scim/v2/...            /iam/governance/scim/v1/...
```

## Stack
Java 25 · Spring Boot 4.1 · `RestClient` · UnboundID SCIM 2 SDK 6.0 (`scim2-sdk-common`) · Jackson 3

## Konfiguration
| Property | Umgebungsvariable | Bedeutung |
|---|---|---|
| `oig.base-url` | `OIG_BASE_URL` | z.B. `https://oig-host:14000/iam/governance/scim/v1` |
| `oig.username` | `OIG_USERNAME` | technischer Benutzer (Basic Auth) |
| `oig.password` | `OIG_PASSWORD` | Passwort — nie ins Repository |

## Aufbau
```
de.bund.bamf.debev.ng.idm.oig.client
├── IdmOigClientApplication
├── config/       OigProperties, OigClientConfiguration   (RestClient-Bean)
├── oig/          OigScimClient                           (HTTP zu OIG, Fehleruebersetzung)
├── scim/         ScimResourceType, ScimPaths, ScimMediaType,
│                 ScimErrorException, ScimLocationRewriter
├── service/      ScimResourceService (Ablauf), ScimUserService, ScimGroupService
├── controller/   ScimUserController, ScimGroupController
└── advice/       ScimExceptionHandler                    (SCIM-ErrorResponse rendern)
```

**Request-Weg:** Controller → Service (Pflichtfeld pruefen) → OigScimClient →
OIG → Antwort → `ScimLocationRewriter` (meta.location auf Hub-URL) → Controller.

**Fehler-Weg:** OIG-`ErrorResponse` → `ScimErrorException` → `ScimExceptionHandler`
→ derselbe Status beim IdP (404 bleibt 404, 409 bleibt 409). OIG nicht
erreichbar → 502.

## Tests
| Klasse | Art | Prueft |
|---|---|---|
| `OigScimClientTest` | Unit, `MockRestServiceServer` | alle Operationen + alle Fehlerwege |
| `OigScimClientUserQueryTest` | `@RestClientTest` | Get by id, by userName, by search criteria, Search |
| `ScimUserServiceTest` | Unit, Mockito | Ablauflogik des Services |
| `ScimLocationRewriterTest` | Unit | meta.location-Umschreibung |
| `IdmOigClientApplicationTests` | `@SpringBootTest` | Kontext startet |

```
mvn test
```

Falls `@RestClientTest` nicht aufloest: Import in `OigScimClientUserQueryTest`
pruefen — Boot 4: `org.springframework.boot.restclient.test.autoconfigure.RestClientTest`,
Boot 3: `org.springframework.boot.test.autoconfigure.web.client.RestClientTest`.

## Manuell testen
`TestJSON/scim-demo.http` enthaelt Beispiel-Requests gegen den laufenden Hub
(IntelliJ HTTP Client). Die Antworten kommen dann aus OIG.

## Offene Punkte
- Auth gegenueber OIG ist Basic; bei OAuth/JWT `setBasicAuth` in
  `OigClientConfiguration` durch einen `requestInterceptor` ersetzen.
- Auth des IdP gegenueber dem Hub (Bearer-Token) ist noch nicht drin.
- Attribut-Mapping auf die OIG-Extension
  (`urn:ietf:params:scim:schemas:extension:oracle:2.0:OIG:User`) falls OIG
  Pflichtfelder verlangt, die der IdP nicht liefert — Platz dafuer ist
  `ScimResourceService.create()` vor dem OIG-Aufruf.
