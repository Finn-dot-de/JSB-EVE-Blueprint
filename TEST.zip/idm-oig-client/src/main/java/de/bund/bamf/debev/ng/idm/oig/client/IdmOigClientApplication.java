package de.bund.bamf.debev.ng.idm.oig.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdmOigClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(IdmOigClientApplication.class, args);
    }
}
