package de.bund.bamf.debev.ng.idm.oig.client.config;

import com.unboundid.scim2.common.utils.JsonUtils;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import org.springframework.web.client.RestClient;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimMediaType;

/**
 * Der {@link RestClient} fuer OIG.
 * <p>
 * Entscheidend ist der Message-Converter: er benutzt den ObjectMapper des
 * SCIM-SDK ({@link JsonUtils#createObjectMapper()}) statt Springs Default.
 * Nur so werden {@code schemas}, {@code meta} und die Extension-URNs genau so
 * serialisiert, wie OIG sie erwartet und liefert.
 * <p>
 * Der {@link RestClient.Builder} wird injiziert statt hier erzeugt, damit
 * Tests einen {@code MockRestServiceServer} daran binden koennen.
 */
@Configuration
@EnableConfigurationProperties(OigProperties.class)
public class OigClientConfiguration {

    @Bean
    public RestClient oigRestClient(OigProperties props, RestClient.Builder builder) {
        return builder
                .baseUrl(props.baseUrl())
                .defaultHeaders(headers -> {
                    headers.setBasicAuth(props.username(), props.password());
                    headers.set(HttpHeaders.ACCEPT, ScimMediaType.SCIM_JSON_VALUE);
                    headers.set(HttpHeaders.CONTENT_TYPE, ScimMediaType.SCIM_JSON_VALUE);
                })
                .messageConverters(converters -> {
                    converters.clear();
                    converters.add(new JacksonJsonHttpMessageConverter(JsonUtils.createObjectMapper()));
                })
                .build();
    }
}
