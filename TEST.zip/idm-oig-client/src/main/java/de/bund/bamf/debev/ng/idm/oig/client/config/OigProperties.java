package de.bund.bamf.debev.ng.idm.oig.client.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Verbindungsdaten zur OIG-SCIM-API, gebunden aus {@code oig.*} in den
 * application.properties.
 *
 * @param baseUrl  z.B. {@code https://oig-host:14000/iam/governance/scim/v1}
 * @param username technischer Benutzer fuer Basic Auth
 * @param password Passwort (nur ueber Umgebungsvariable, nie im Repository)
 */
@ConfigurationProperties(prefix = "oig")
public record OigProperties(String baseUrl, String username, String password) {
}
