package de.bund.bamf.debev.ng.idm.oig.client.scim;

import com.unboundid.scim2.common.BaseScimResource;
import com.unboundid.scim2.common.types.Meta;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

/**
 * Ersetzt {@code meta.location} einer von OIG gelieferten Ressource durch die
 * Adresse des Hubs.
 * <p>
 * OIG traegt seine eigene URL ein ({@code https://oig-host/iam/governance/
 * scim/v1/Users/42}). Der IdP kennt aber nur den Hub — folgt er dieser
 * Location, laeuft er ins Leere oder umgeht den Hub. Alle anderen
 * Meta-Felder (created, lastModified, version) kommen unveraendert von OIG.
 * Loest {@code ScimMetaFactory} ab, die es ohne eigene Datenhaltung nicht mehr
 * braucht.
 */
@Component
public class ScimLocationRewriter {

    public <R extends BaseScimResource> R relocate(ScimResourceType type, R resource) {
        Meta meta = resource.getMeta();
        if (meta == null) {
            meta = new Meta();
            meta.setResourceType(type.typeName());
            resource.setMeta(meta);
        }
        meta.setLocation(locationOf(type, resource.getId()));
        return resource;
    }

    private URI locationOf(ScimResourceType type, String id) {
        return ServletUriComponentsBuilder.fromCurrentContextPath()
                .path(type.path())
                .path("/{id}")
                .buildAndExpand(id)
                .toUri();
    }
}
