package de.bund.bamf.debev.ng.idm.oig.client.scim;

/**
 * Beschreibt eine SCIM-Ressourcenart an genau einer Stelle: wie sie in
 * {@code meta.resourceType} heisst, unter welchem Pfad der Hub sie anbietet,
 * unter welchem Pfad OIG sie anbietet und welches Attribut sie fachlich
 * eindeutig macht.
 */
public enum ScimResourceType {

    USER("User", ScimPaths.USERS, "/Users", "userName"),
    GROUP("Group", ScimPaths.GROUPS, "/Groups", "displayName");

    /** Wert fuer {@code meta.resourceType}. */
    private final String typeName;

    /** Pfad im Hub, z.B. {@code /scim/v2/Users}. Landet in {@code meta.location}. */
    private final String path;

    /** Pfad relativ zur OIG-Base-URL, z.B. {@code /Users}. */
    private final String remotePath;

    /** Fachlicher Schluessel: {@code userName} bzw. {@code displayName}. */
    private final String uniqueAttribute;

    ScimResourceType(String typeName, String path, String remotePath, String uniqueAttribute) {
        this.typeName = typeName;
        this.path = path;
        this.remotePath = remotePath;
        this.uniqueAttribute = uniqueAttribute;
    }

    public String typeName() {
        return typeName;
    }

    public String path() {
        return path;
    }

    public String remotePath() {
        return remotePath;
    }

    public String uniqueAttribute() {
        return uniqueAttribute;
    }
}
