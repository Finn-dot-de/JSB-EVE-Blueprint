package de.bund.bamf.debev.ng.idm.oig.client.service;

import com.unboundid.scim2.common.types.GroupResource;
import org.jspecify.annotations.Nullable;
import org.springframework.stereotype.Service;
import de.bund.bamf.debev.ng.idm.oig.client.oig.OigScimClient;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimLocationRewriter;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimResourceType;

/**
 * SCIM-/Groups-Service. Die gesamte Ablauflogik steckt in
 * {@link ScimResourceService} — hier steht nur, was die Gruppe ausmacht.
 */
@Service
public class ScimGroupService extends ScimResourceService<GroupResource> {

    public ScimGroupService(OigScimClient oig, ScimLocationRewriter locations) {
        super(oig, locations);
    }

    @Override
    protected ScimResourceType type() {
        return ScimResourceType.GROUP;
    }

    @Override
    protected Class<GroupResource> resourceClass() {
        return GroupResource.class;
    }

    @Override
    protected @Nullable String uniqueAttributeOf(GroupResource resource) {
        return resource.getDisplayName();
    }
}
