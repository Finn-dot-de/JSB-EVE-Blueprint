package de.bund.bamf.debev.ng.idm.oig.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/** Stellt sicher, dass der Kontext ohne laufendes OIG startet. */
@SpringBootTest(properties = {
        "oig.base-url=https://oig.example/iam/governance/scim/v1",
        "oig.username=test",
        "oig.password=test"
})
class IdmOigClientApplicationTests {

    @Test
    void contextLoads() {
    }
}
