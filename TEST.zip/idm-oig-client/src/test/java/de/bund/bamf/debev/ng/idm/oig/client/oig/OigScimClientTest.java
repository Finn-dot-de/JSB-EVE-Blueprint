package de.bund.bamf.debev.ng.idm.oig.client.oig;

import com.unboundid.scim2.common.messages.ListResponse;
import com.unboundid.scim2.common.messages.PatchOperation;
import com.unboundid.scim2.common.messages.PatchRequest;
import com.unboundid.scim2.common.types.GroupResource;
import com.unboundid.scim2.common.types.UserResource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;
import de.bund.bamf.debev.ng.idm.oig.client.config.OigClientConfiguration;
import de.bund.bamf.debev.ng.idm.oig.client.config.OigProperties;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimErrorException;

import java.io.IOException;
import java.net.ConnectException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.queryParam;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withException;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withNoContent;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static de.bund.bamf.debev.ng.idm.oig.client.scim.ScimResourceType.GROUP;
import static de.bund.bamf.debev.ng.idm.oig.client.scim.ScimResourceType.USER;

/**
 * Prueft den HTTP-Client gegen einen simulierten OIG-Server: Ohne Netz, ohne
 * Spring-Kontext. {@link MockRestServiceServer} faengt jeden Request ab und
 * liefert die hier vorgegebene Antwort.
 * <p>
 * Der {@code RestClient} wird ueber die echte {@link OigClientConfiguration}
 * gebaut, damit auch Header und Message-Converter mitgetestet sind.
 */
class OigScimClientTest {

    private static final String BASE_URL = "https://oig.example/iam/governance/scim/v1";
    private static final MediaType SCIM_JSON = MediaType.parseMediaType("application/scim+json");

    private MockRestServiceServer oig;
    private OigScimClient client;

    @BeforeEach
    void setUp() {
        RestClient.Builder builder = RestClient.builder();
        oig = MockRestServiceServer.bindTo(builder).build();

        OigProperties props = new OigProperties(BASE_URL, "xelsysadm", "geheim");
        client = new OigScimClient(new OigClientConfiguration().oigRestClient(props, builder));
    }

    // ------------------------------------------------------------------
    // Testdaten
    // ------------------------------------------------------------------

    private static final String USER_JSON = """
            {
              "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
              "id": "4711",
              "userName": "m.schneider@example.de",
              "active": true,
              "meta": {
                "resourceType": "User",
                "created": "2026-09-01T08:00:00Z",
                "lastModified": "2026-09-01T08:00:00Z",
                "location": "%s/Users/4711"
              }
            }""".formatted(BASE_URL);

    private static final String GROUP_JSON = """
            {
              "schemas": ["urn:ietf:params:scim:schemas:core:2.0:Group"],
              "id": "77",
              "displayName": "Sachbearbeitung",
              "members": [ { "value": "4711", "display": "Maria Schneider" } ]
            }""";

    private static String scimError(int status, String scimType, String detail) {
        return """
                {
                  "schemas": ["urn:ietf:params:scim:api:messages:2.0:Error"],
                  "status": "%d",
                  "scimType": "%s",
                  "detail": "%s"
                }""".formatted(status, scimType, detail);
    }

    // ------------------------------------------------------------------
    // Erfolgsfaelle
    // ------------------------------------------------------------------

    @Nested
    class Erfolg {

        @Test
        void createSchicktPostMitScimHeadernUndBasicAuth() {
            oig.expect(requestTo(BASE_URL + "/Users"))
                    .andExpect(method(HttpMethod.POST))
                    .andExpect(header("Content-Type", "application/scim+json"))
                    .andExpect(header("Accept", "application/scim+json"))
                    .andExpect(header("Authorization", "Basic eGVsc3lzYWRtOmdlaGVpbQ=="))
                    .andExpect(jsonPath("$.userName").value("m.schneider@example.de"))
                    .andExpect(jsonPath("$.schemas[0]").value("urn:ietf:params:scim:schemas:core:2.0:User"))
                    .andRespond(withStatus(HttpStatus.CREATED).contentType(SCIM_JSON).body(USER_JSON));

            UserResource neu = new UserResource().setUserName("m.schneider@example.de");
            UserResource erzeugt = client.create(USER, UserResource.class, neu);

            assertThat(erzeugt.getId()).isEqualTo("4711");
            assertThat(erzeugt.getMeta().getResourceType()).isEqualTo("User");
            oig.verify();
        }

        @Test
        void getLiestEinzelneRessourceUnterIhrerId() {
            oig.expect(requestTo(BASE_URL + "/Users/4711"))
                    .andExpect(method(HttpMethod.GET))
                    .andRespond(withSuccess(USER_JSON, SCIM_JSON));

            UserResource user = client.get(USER, UserResource.class, "4711");

            assertThat(user.getUserName()).isEqualTo("m.schneider@example.de");
            assertThat(user.getActive()).isTrue();
            oig.verify();
        }

        @Test
        void searchReichtFilterUndPagingAlsQueryParameterDurch() {
            String listJson = """
                    {
                      "schemas": ["urn:ietf:params:scim:api:messages:2.0:ListResponse"],
                      "totalResults": 1,
                      "startIndex": 1,
                      "itemsPerPage": 10,
                      "Resources": [ %s ]
                    }""".formatted(USER_JSON);

            oig.expect(method(HttpMethod.GET))
                    .andExpect(request -> assertThat(request.getURI().getPath()).endsWith("/Users"))
                    // getQuery() liefert den dekodierten String, unabhaengig davon,
                    // wie der RestClient Leerzeichen und Anfuehrungszeichen kodiert.
                    .andExpect(request -> assertThat(request.getURI().getQuery())
                            .contains("filter=userName eq \"m.schneider@example.de\""))
                    .andExpect(queryParam("startIndex", "1"))
                    .andExpect(queryParam("count", "10"))
                    .andRespond(withSuccess(listJson, SCIM_JSON));

            ListResponse<UserResource> ergebnis = client.search(
                    USER, UserResource.class, "userName eq \"m.schneider@example.de\"", 1, 10);

            assertThat(ergebnis.getTotalResults()).isEqualTo(1);
            assertThat(ergebnis.getResources()).hasSize(1);
            // Der generische Typ muss korrekt aufgeloest sein — sonst kaeme hier
            // eine LinkedHashMap statt einer UserResource zurueck.
            assertThat(ergebnis.getResources().getFirst()).isInstanceOf(UserResource.class);
            assertThat(ergebnis.getResources().getFirst().getUserName()).isEqualTo("m.schneider@example.de");
            oig.verify();
        }

        @Test
        void searchOhneFilterSendetKeinenFilterParameter() {
            oig.expect(method(HttpMethod.GET))
                    .andExpect(request -> assertThat(request.getURI().getQuery()).doesNotContain("filter"))
                    .andRespond(withSuccess("""
                            { "schemas": ["urn:ietf:params:scim:api:messages:2.0:ListResponse"],
                              "totalResults": 0, "startIndex": 1, "itemsPerPage": 0, "Resources": [] }""",
                            SCIM_JSON));

            ListResponse<GroupResource> ergebnis = client.search(GROUP, GroupResource.class, null, 1, 100);

            assertThat(ergebnis.getTotalResults()).isZero();
            assertThat(ergebnis.getResources()).isEmpty();
            oig.verify();
        }

        @Test
        void patchSchicktPatchRequestUnveraendertAnOig() {
            oig.expect(requestTo(BASE_URL + "/Groups/77"))
                    .andExpect(method(HttpMethod.PATCH))
                    .andExpect(jsonPath("$.schemas[0]").value("urn:ietf:params:scim:api:messages:2.0:PatchOp"))
                    .andExpect(jsonPath("$.Operations[0].op").value("replace"))
                    .andExpect(jsonPath("$.Operations[0].path").value("displayName"))
                    .andExpect(jsonPath("$.Operations[0].value").value("Sachbearbeitung"))
                    .andRespond(withSuccess(GROUP_JSON, SCIM_JSON));

            PatchRequest patch = new PatchRequest(List.of(
                    PatchOperation.replace("displayName", "Sachbearbeitung")));
            GroupResource gruppe = client.patch(GROUP, GroupResource.class, "77", patch);

            assertThat(gruppe.getDisplayName()).isEqualTo("Sachbearbeitung");
            assertThat(gruppe.getMembers()).singleElement()
                    .satisfies(m -> assertThat(m.getValue()).isEqualTo("4711"));
            oig.verify();
        }

        @Test
        void deleteAkzeptiert204OhneBody() {
            oig.expect(requestTo(BASE_URL + "/Users/4711"))
                    .andExpect(method(HttpMethod.DELETE))
                    .andRespond(withNoContent());

            client.delete(USER, "4711");

            oig.verify();
        }
    }

    // ------------------------------------------------------------------
    // Fehleruebersetzung
    // ------------------------------------------------------------------

    @Nested
    class Fehler {

        @Test
        void notFoundVonOigWirdZuScimErrorMitStatus404() {
            oig.expect(requestTo(BASE_URL + "/Users/999"))
                    .andRespond(withStatus(HttpStatus.NOT_FOUND).contentType(SCIM_JSON)
                            .body(scimError(404, "", "User 999 not found")));

            assertThatThrownBy(() -> client.get(USER, UserResource.class, "999"))
                    .isInstanceOfSatisfying(ScimErrorException.class, ex -> {
                        assertThat(ex.error().getStatus()).isEqualTo(404);
                        assertThat(ex.error().getDetail()).isEqualTo("User 999 not found");
                    });
        }

        @Test
        void conflictVonOigBehaeltScimTypeUndDetail() {
            oig.expect(requestTo(BASE_URL + "/Users"))
                    .andRespond(withStatus(HttpStatus.CONFLICT).contentType(SCIM_JSON)
                            .body(scimError(409, "uniqueness", "userName already exists")));

            assertThatThrownBy(() -> client.create(USER, UserResource.class,
                    new UserResource().setUserName("doppelt")))
                    .isInstanceOfSatisfying(ScimErrorException.class, ex -> {
                        assertThat(ex.error().getStatus()).isEqualTo(409);
                        assertThat(ex.error().getScimType()).isEqualTo("uniqueness");
                        assertThat(ex.error().getDetail()).isEqualTo("userName already exists");
                    });
        }

        @Test
        void fehlerantwortOhneScimJsonBehaeltWenigstensDenStatus() {
            oig.expect(requestTo(BASE_URL + "/Groups/77"))
                    .andRespond(withStatus(HttpStatus.INTERNAL_SERVER_ERROR)
                            .contentType(MediaType.TEXT_HTML)
                            .body("<html><body>Oracle WebLogic Server Error</body></html>"));

            assertThatThrownBy(() -> client.get(GROUP, GroupResource.class, "77"))
                    .isInstanceOfSatisfying(ScimErrorException.class, ex -> {
                        assertThat(ex.error().getStatus()).isEqualTo(500);
                        assertThat(ex.error().getDetail()).contains("500");
                        // Interna des Backends duerfen nicht nach aussen.
                        assertThat(ex.error().getDetail()).doesNotContain("WebLogic");
                    });
        }

        @Test
        void verbindungsfehlerWirdZuBadGateway() {
            oig.expect(requestTo(BASE_URL + "/Users/4711"))
                    .andRespond(withException(new ConnectException("Connection refused")));

            assertThatThrownBy(() -> client.get(USER, UserResource.class, "4711"))
                    .isInstanceOfSatisfying(ScimErrorException.class, ex -> {
                        assertThat(ex.error().getStatus()).isEqualTo(502);
                        assertThat(ex.error().getDetail()).doesNotContain("Connection refused");
                    });
        }

        @Test
        void timeoutWirdEbenfallsZuBadGateway() {
            oig.expect(requestTo(BASE_URL + "/Users/4711"))
                    .andRespond(withException(new IOException("Read timed out")));

            assertThatThrownBy(() -> client.get(USER, UserResource.class, "4711"))
                    .isInstanceOfSatisfying(ScimErrorException.class,
                            ex -> assertThat(ex.error().getStatus()).isEqualTo(502));
        }

        @Test
        void leererErfolgsbodyWirdNichtStillDurchgereicht() {
            oig.expect(requestTo(BASE_URL + "/Users/4711"))
                    .andRespond(withSuccess());

            assertThatThrownBy(() -> client.get(USER, UserResource.class, "4711"))
                    .isInstanceOf(NullPointerException.class)
                    .hasMessageContaining("leere Antwort");
        }
    }
}
