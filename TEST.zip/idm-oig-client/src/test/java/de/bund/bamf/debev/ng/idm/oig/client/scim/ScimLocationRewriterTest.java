package de.bund.bamf.debev.ng.idm.oig.client.scim;

import com.unboundid.scim2.common.types.GroupResource;
import com.unboundid.scim2.common.types.Meta;
import com.unboundid.scim2.common.types.UserResource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.net.URI;
import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Der Rewriter leitet die Hub-Adresse aus dem laufenden Request ab. Im
 * Unit-Test gibt es keinen, deshalb wird ein {@link MockHttpServletRequest}
 * in den {@link RequestContextHolder} gelegt — genau das, was Spring MVC im
 * Betrieb pro Request tut.
 */
class ScimLocationRewriterTest {

    private final ScimLocationRewriter rewriter = new ScimLocationRewriter();

    @BeforeEach
    void requestKontextSetzen() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setScheme("https");
        request.setServerName("idm-hub.example");
        request.setServerPort(8443);
        request.setContextPath("/hub");
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
    }

    @AfterEach
    void requestKontextAufraeumen() {
        RequestContextHolder.resetRequestAttributes();
    }

    @Test
    void ersetztOigLocationDurchHubAdresse() {
        UserResource user = new UserResource().setUserName("maria");
        user.setId("4711");
        Meta meta = new Meta();
        meta.setResourceType("User");
        meta.setLocation(URI.create("https://oig-host:14000/iam/governance/scim/v1/Users/4711"));
        user.setMeta(meta);

        rewriter.relocate(ScimResourceType.USER, user);

        assertThat(user.getMeta().getLocation())
                .isEqualTo(URI.create("https://idm-hub.example:8443/hub/scim/v2/Users/4711"));
    }

    @Test
    void laesstAlleAnderenMetaFelderUnangetastet() {
        Calendar created = new GregorianCalendar(2026, Calendar.SEPTEMBER, 1, 8, 0);
        Meta meta = new Meta();
        meta.setResourceType("Group");
        meta.setCreated(created);
        meta.setVersion("W/\"abc\"");
        meta.setLocation(URI.create("https://oig-host/Groups/77"));
        GroupResource gruppe = new GroupResource().setDisplayName("Sachbearbeitung");
        gruppe.setId("77");
        gruppe.setMeta(meta);

        rewriter.relocate(ScimResourceType.GROUP, gruppe);

        assertThat(gruppe.getMeta().getCreated()).isEqualTo(created);
        assertThat(gruppe.getMeta().getVersion()).isEqualTo("W/\"abc\"");
        assertThat(gruppe.getMeta().getResourceType()).isEqualTo("Group");
        assertThat(gruppe.getMeta().getLocation().getPath()).isEqualTo("/hub/scim/v2/Groups/77");
    }

    @Test
    void legtMetaAnWennOigKeinesLiefert() {
        UserResource user = new UserResource().setUserName("maria");
        user.setId("4711");
        assertThat(user.getMeta()).isNull();

        rewriter.relocate(ScimResourceType.USER, user);

        assertThat(user.getMeta()).isNotNull();
        assertThat(user.getMeta().getResourceType()).isEqualTo("User");
        assertThat(user.getMeta().getLocation().getPath()).isEqualTo("/hub/scim/v2/Users/4711");
    }

    @Test
    void gibtDieselbeInstanzZurueck() {
        UserResource user = new UserResource().setUserName("maria");
        user.setId("1");

        UserResource ergebnis = rewriter.relocate(ScimResourceType.USER, user);

        assertThat(ergebnis).isSameAs(user);
    }
}
