package de.bund.bamf.debev.ng.idm.oig.client.advice;

import com.unboundid.scim2.common.exceptions.ScimException;
import com.unboundid.scim2.common.messages.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimErrorException;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimMediaType;


@Slf4j
@RestControllerAdvice
public class ScimExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(ScimErrorException.class)
    public ResponseEntity<Object> handleScimError(ScimErrorException ex, WebRequest request) {
        return respond(ex.error(), ex, request);
    }

    @ExceptionHandler(ScimException.class)
    public ResponseEntity<Object> handleSdkError(ScimException ex, WebRequest request) {
        return respond(ex.getScimError(), ex, request);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleUnexpected(Exception ex, WebRequest request) {
        log.error("Unerwarteter Fehler bei der SCIM-Verarbeitung", ex);
        return respond(
                scimError(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        "Interner Fehler im SCIM-Endpunkt."),
                ex, request);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(
            @NonNull Exception ex, @Nullable Object body, @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status, @NonNull WebRequest request) {

        Object scimBody = (body instanceof ErrorResponse)
                ? body
                : scimError(status.value(), ex.getMessage());

        return super.handleExceptionInternal(ex, scimBody, scimHeaders(headers), status, request);
    }

    private ResponseEntity<Object> respond(ErrorResponse error, Exception ex, WebRequest request) {
        return handleExceptionInternal(
                ex, error, new HttpHeaders(), HttpStatusCode.valueOf(error.getStatus()), request);
    }

    private static ErrorResponse scimError(int status, @Nullable String detail) {
        ErrorResponse error = new ErrorResponse(status);
        error.setDetail(detail);
        return error;
    }

    private static HttpHeaders scimHeaders(HttpHeaders headers) {
        HttpHeaders scimHeaders = new HttpHeaders();
        scimHeaders.putAll(headers);
        scimHeaders.setContentType(ScimMediaType.SCIM_JSON);
        return scimHeaders;
    }
}
