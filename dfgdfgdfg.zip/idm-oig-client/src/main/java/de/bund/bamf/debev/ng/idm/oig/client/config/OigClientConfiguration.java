package de.bund.bamf.debev.ng.idm.oig.client.config;

import com.unboundid.scim2.common.utils.JsonUtils;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import org.springframework.web.client.RestClient;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimMediaType;


@Configuration
@EnableConfigurationProperties(OigProperties.class)
public class OigClientConfiguration {

    @Bean
    public RestClient oigRestClient(OigProperties props, RestClient.Builder builder) {
        return builder
                .baseUrl(props.baseUrl())
                .defaultHeaders(headers -> {
                    headers.setBasicAuth(props.username(), props.password());
                    headers.set(HttpHeaders.ACCEPT, ScimMediaType.SCIM_JSON_VALUE);
                    headers.set(HttpHeaders.CONTENT_TYPE, ScimMediaType.SCIM_JSON_VALUE);
                })
                .messageConverters(converters -> {
                    converters.clear();
                    converters.add(new JacksonJsonHttpMessageConverter(JsonUtils.createObjectMapper()));
                })
                .build();
    }
}
