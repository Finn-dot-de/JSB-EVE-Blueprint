package de.bund.bamf.debev.ng.idm.oig.client.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "oig")
public record OigProperties(String baseUrl, String username, String password) {
}
