package de.bund.bamf.debev.ng.idm.oig.client.scim;

import com.unboundid.scim2.common.exceptions.ScimException;
import com.unboundid.scim2.common.messages.ErrorResponse;
import org.jspecify.annotations.Nullable;

public class ScimErrorException extends RuntimeException {

    private static final int BAD_REQUEST = 400;
    private static final int NOT_FOUND = 404;
    private static final int CONFLICT = 409;
    private static final int BAD_GATEWAY = 502;

    private final transient ErrorResponse error;

    private ScimErrorException(ErrorResponse error, @Nullable Throwable cause) {
        super(error.getDetail(), cause);
        this.error = error;
    }

    public static ScimErrorException notFound(ScimResourceType type, String id) {
        return new ScimErrorException(
                errorResponse(NOT_FOUND, null,
                        "%s mit der ID '%s' existiert nicht.".formatted(type.typeName(), id)),
                null);
    }

    public static ScimErrorException conflict(ScimResourceType type, String uniqueValue) {
        return new ScimErrorException(
                errorResponse(CONFLICT, "uniqueness",
                        "%s mit %s '%s' existiert bereits.".formatted(
                                type.typeName(), type.uniqueAttribute(), uniqueValue)),
                null);
    }

    public static ScimErrorException badRequest(String scimType, String detail) {
        return new ScimErrorException(errorResponse(BAD_REQUEST, scimType, detail), null);
    }

    public static ScimErrorException badGateway(String detail) {
        return new ScimErrorException(errorResponse(BAD_GATEWAY, null, detail), null);
    }


    public static ScimErrorException from(ScimException cause) {
        return new ScimErrorException(cause.getScimError(), cause);
    }

    public static ScimErrorException from(ErrorResponse error) {
        return new ScimErrorException(error, null);
    }

    public ErrorResponse error() {
        return error;
    }

    private static ErrorResponse errorResponse(int status, @Nullable String scimType, String detail) {
        ErrorResponse response = new ErrorResponse(status);
        response.setDetail(detail);
        if (scimType != null) {
            response.setScimType(scimType);
        }
        return response;
    }
}
