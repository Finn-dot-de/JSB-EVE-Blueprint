package de.bund.bamf.debev.ng.idm.oig.client.scim;

import com.unboundid.scim2.common.BaseScimResource;
import com.unboundid.scim2.common.types.Meta;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@Component
public class ScimLocationRewriter {

    public <R extends BaseScimResource> R relocate(ScimResourceType type, R resource) {
        Meta meta = resource.getMeta();
        if (meta == null) {
            meta = new Meta();
            meta.setResourceType(type.typeName());
            resource.setMeta(meta);
        }
        meta.setLocation(locationOf(type, resource.getId()));
        return resource;
    }

    private URI locationOf(ScimResourceType type, String id) {
        return ServletUriComponentsBuilder.fromCurrentContextPath()
                .path(type.path())
                .path("/{id}")
                .buildAndExpand(id)
                .toUri();
    }
}
