package de.bund.bamf.debev.ng.idm.oig.client.scim;

import org.springframework.http.MediaType;

public final class ScimMediaType {

    public static final String SCIM_JSON_VALUE = "application/scim+json";

    public static final MediaType SCIM_JSON = MediaType.parseMediaType(SCIM_JSON_VALUE);

    private ScimMediaType() {
    }
}
