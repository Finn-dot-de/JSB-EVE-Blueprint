package de.bund.bamf.debev.ng.idm.oig.client.scim;

public final class ScimPaths {

    public static final String BASE = "/scim/v2";

    public static final String USERS = BASE + "/Users";

    public static final String GROUPS = BASE + "/Groups";

    private ScimPaths() {
    }
}
