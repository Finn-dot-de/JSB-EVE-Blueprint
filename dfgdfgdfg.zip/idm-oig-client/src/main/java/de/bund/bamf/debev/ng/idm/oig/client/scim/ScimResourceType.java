package de.bund.bamf.debev.ng.idm.oig.client.scim;


public enum ScimResourceType {

    USER("User", ScimPaths.USERS, "/Users", "userName"),
    GROUP("Group", ScimPaths.GROUPS, "/Groups", "displayName");

    private final String typeName;

    private final String path;

    private final String remotePath;

    private final String uniqueAttribute;

    ScimResourceType(String typeName, String path, String remotePath, String uniqueAttribute) {
        this.typeName = typeName;
        this.path = path;
        this.remotePath = remotePath;
        this.uniqueAttribute = uniqueAttribute;
    }

    public String typeName() {
        return typeName;
    }

    public String path() {
        return path;
    }

    public String remotePath() {
        return remotePath;
    }

    public String uniqueAttribute() {
        return uniqueAttribute;
    }
}
