package de.bund.bamf.debev.ng.idm.oig.client.service;

import com.unboundid.scim2.common.BaseScimResource;
import com.unboundid.scim2.common.messages.ListResponse;
import com.unboundid.scim2.common.messages.PatchRequest;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.Nullable;
import org.springframework.util.StringUtils;
import de.bund.bamf.debev.ng.idm.oig.client.OigScimClient;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimErrorException;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimLocationRewriter;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimResourceType;

@Slf4j
public abstract class ScimResourceService<R extends BaseScimResource> {

    private final OigScimClient oig;
    private final ScimLocationRewriter locations;

    protected ScimResourceService(OigScimClient oig, ScimLocationRewriter locations) {
        this.oig = oig;
        this.locations = locations;
    }

    public R create(R resource) {
        String uniqueValue = requireUniqueAttribute(resource);
        log.info("Lege {} in OIG an: {}", type().typeName(), uniqueValue);

        return relocate(oig.create(type(), resourceClass(), resource));
    }

    public R findById(String id) {
        return relocate(oig.get(type(), resourceClass(), id));
    }

    public ListResponse<R> search(@Nullable String filterExpression, int startIndex, int count) {
        log.debug("Suche {} in OIG. Filter: '{}', Start: {}, Count: {}",
                type().typeName(), filterExpression, startIndex, count);

        ListResponse<R> result = oig.search(type(), resourceClass(), filterExpression, startIndex, count);

        return new ListResponse<>(
                result.getTotalResults(),
                result.getResources().stream().map(this::relocate).toList(),
                result.getStartIndex(),
                result.getItemsPerPage());
    }

    public R patch(String id, PatchRequest patchRequest) {
        log.info("Patche {} {} in OIG", type().typeName(), id);
        return relocate(oig.patch(type(), resourceClass(), id, patchRequest));
    }

    public void delete(String id) {
        oig.delete(type(), id);
        log.info("{} {} in OIG geloescht", type().typeName(), id);
    }

    // ------------------------------------------------------------------
    // Hub-spezifisches
    // ------------------------------------------------------------------

    private R relocate(R resource) {
        return locations.relocate(type(), resource);
    }

    private String requireUniqueAttribute(R resource) {
        String value = uniqueAttributeOf(resource);
        if (!StringUtils.hasText(value)) {
            throw ScimErrorException.badRequest("invalidValue",
                    "%s ist ein Pflichtfeld.".formatted(type().uniqueAttribute()));
        }
        return value;
    }

    // ------------------------------------------------------------------
    // Haken der konkreten Ressource
    // ------------------------------------------------------------------

    /** Ressourcenart samt Hub-Pfad, OIG-Pfad und Name des Eindeutigkeitsattributs. */
    protected abstract ScimResourceType type();

    /** Zieltyp fuer die Deserialisierung der OIG-Antwort. */
    protected abstract Class<R> resourceClass();

    /** {@code userName} beim User, {@code displayName} bei der Gruppe. */
    protected abstract @Nullable String uniqueAttributeOf(R resource);
}
