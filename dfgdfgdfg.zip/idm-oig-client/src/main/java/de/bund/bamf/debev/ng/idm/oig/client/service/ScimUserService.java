package de.bund.bamf.debev.ng.idm.oig.client.service;

import com.unboundid.scim2.common.types.UserResource;
import org.jspecify.annotations.Nullable;
import org.springframework.stereotype.Service;
import de.bund.bamf.debev.ng.idm.oig.client.OigScimClient;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimLocationRewriter;
import de.bund.bamf.debev.ng.idm.oig.client.scim.ScimResourceType;

@Service
public class ScimUserService extends ScimResourceService<UserResource> {

    public ScimUserService(OigScimClient oig, ScimLocationRewriter locations) {
        super(oig, locations);
    }

    @Override
    protected ScimResourceType type() {
        return ScimResourceType.USER;
    }

    @Override
    protected Class<UserResource> resourceClass() {
        return UserResource.class;
    }

    @Override
    protected @Nullable String uniqueAttributeOf(UserResource resource) {
        return resource.getUserName();
    }
}
