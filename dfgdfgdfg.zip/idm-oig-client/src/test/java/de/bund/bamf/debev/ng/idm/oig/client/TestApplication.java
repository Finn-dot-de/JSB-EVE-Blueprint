package de.bund.bamf.debev.ng.idm.oig.client;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Die Bibliothek bringt selbst keine {@code @SpringBootApplication} mit — sie wird ja
 * von einer fremden Anwendung eingebunden. Boot-Slice-Tests wie {@code @RestClientTest}
 * suchen aber aufwaerts nach einer {@code @SpringBootConfiguration} und registrieren die
 * dort gescannten Komponenten. Diese Klasse uebernimmt im Testumfang die Rolle der
 * einbindenden Anwendung; ihre Auto-Konfiguration schaltet der Slice-Test selbst ab.
 */
@SpringBootApplication
class TestApplication {
}
